﻿Module Module1

    Sub Main()
        'DECLARAR VARIABLES
        Dim a, b As Integer
        Dim da, db As Double
        Dim sa, sb As String

        'ARREGLOS, MATRICES
        Dim arreglo() As Integer 'arreglo sin tamaño
        Dim arr(5) As Double 'el arreglo sería de 6 posiciones
        Dim matriz()() As Char 'matriz de caracteres sin tamaño

        'Mostrar mensajes en pantalla
        Console.Write("INGRESE UN NUMERO: ")
        'Leer del teclado
        a = Console.ReadLine 'lee toda la linea de la consola

        'Definir el tamaño de un arreglo
        ReDim arreglo(a - 1) 'define el arreglo de tamaño a

        'Aumentar una posicion al arreglo sin perder la información
        ReDim Preserve arr(arr.Length)

        Console.WriteLine("Los valores del arreglo son: ")
        'ciclo for en donde i aumenta de 1 en 1
        For i As Integer = 0 To arreglo.Length - 1 'step cuando el aumento es mayor
            arreglo(i) = Rnd() * 100 'números aleatorios entre 0 y 99
            Console.Write(arreglo(i) & "  |  ")
        Next
        Console.WriteLine()

        Console.Read() 'pausa

    End Sub

End Module
